import { 
  Monitor, 
  Cpu, 
  Terminal, 
  Zap, 
  BookOpen, 
  BarChart,
  Smartphone,
  Globe,
  Settings,
  Shield,
  Layers,
  Database
} from 'lucide-react';

const iconMap = {
  Monitor,
  Cpu,
  Terminal,
  Zap,
  BookOpen,
  BarChart,
  Smartphone,
  Globe,
  Settings,
  Shield,
  Layers,
  Database
};

export const getIcon = (name) => {
  return iconMap[name] || Settings; // Fallback to Settings icon
};
