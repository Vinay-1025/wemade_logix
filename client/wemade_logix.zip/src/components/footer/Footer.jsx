import React from "react";
import { NavLink } from "react-router-dom";
import "./footer.css";

const Footer = () => {
  return (
    <footer className="footer-section">

      <div className="container footer-grid">

        {/* Company Info */}
        <div className="footer-info">

          <NavLink to="/" className="footer-logo">
            We Made<span>Logix</span>
          </NavLink>

          <p className="footer-desc">
            We Made Logix builds enterprise software platforms and Generative AI
            solutions that help organizations modernize systems, unlock data
            intelligence, and accelerate digital transformation.
          </p>

        </div>

        {/* Company Links */}
        <div className="footer-links">
          <h4>Company</h4>

          <ul>
            <li><NavLink to="/about">About</NavLink></li>
            <li><NavLink to="/services">Services</NavLink></li>
            <li><NavLink to="/projects">Projects</NavLink></li>
            <li><NavLink to="/trainings">Trainings</NavLink></li>
            <li><NavLink to="/contact">Contact</NavLink></li>
          </ul>
        </div>

        {/* Services */}
        <div className="footer-links">
          <h4>Solutions</h4>

          <ul>
            <li><NavLink to="/services/genai">Generative AI</NavLink></li>
            <li><NavLink to="/services/ai">AI & Machine Learning</NavLink></li>
            <li><NavLink to="/services/software">Enterprise Software</NavLink></li>
            <li><NavLink to="/services/cloud">Cloud Platforms</NavLink></li>
          </ul>
        </div>

        {/* Contact */}
        <div className="footer-contact">
          <h4>Contact</h4>

          <p>Email: info@wemadelogix.com</p>
          <p>Phone: +91 98765 00000</p>
          <p>Location: Hyderabad, India</p>

        </div>

      </div>

      {/* Bottom */}
      <div className="footer-bottom-bar">
        <div className="container footer-bottom">

          <p>
            © {new Date().getFullYear()} We Made Logix. All rights reserved.
          </p>

          <div className="footer-legal">
            <NavLink to="/privacy">Privacy</NavLink>
            <NavLink to="/terms">Terms</NavLink>
          </div>

        </div>
      </div>

    </footer>
  );
};

export default Footer;