import React, { useState, useEffect } from 'react';
import { NavLink } from 'react-router-dom';
import { Menu, X } from 'lucide-react';
import './navbar.css';

const Navbar = ({ logoVariant }) => {
    const [isOpen, setIsOpen] = useState(false);
    const [scrolled, setScrolled] = useState(false);

    useEffect(() => {
        const handleScroll = () => {
            setScrolled(window.scrollY > 20);
        };
        window.addEventListener('scroll', handleScroll);
        return () => window.removeEventListener('scroll', handleScroll);
    }, []);

    const navLinks = [
        { name: 'Home', path: '/' },
        { name: 'About', path: '/about' },
        { name: 'Services', path: '/services' },
        { name: 'Projects', path: '/projects' },
        { name: 'Trainings', path: '/trainings' },
    ];

    const getLogo = () => {
        if (logoVariant === 'services') {
            return scrolled ? '/company_logo.png' : '/company_logo.png';
        }
        return '/company_logo.png';
    };

    return (
        <nav className={`navbar-main ${scrolled ? 'navbar-scrolled' : ''} ${logoVariant ? `navbar-${logoVariant}` : ''}`}>
            <div className="container navbar-nav-container">
                <NavLink to="/" className="navbar-logo">
                    <img src={getLogo()} alt="We Made Logix" className="navbar-logo-img" />
                </NavLink>

                <div className={`navbar-nav-menu ${isOpen ? 'navbar-active' : ''}`}>
                    <div className="navbar-nav-links-container">
                        {navLinks.map((link) => (
                            <NavLink
                                key={link.path}
                                to={link.path}
                                className={({ isActive }) => (isActive ? 'navbar-nav-link navbar-active' : 'navbar-nav-link')}
                                onClick={() => setIsOpen(false)}
                            >
                                {link.name}
                            </NavLink>
                        ))}
                    </div>
                    <NavLink
                        to="/contact"
                        className="navbar-nav-cta"
                        onClick={() => setIsOpen(false)}
                    >
                        Contact Us
                    </NavLink>
                </div>

                <div className="navbar-nav-mobile-toggle" onClick={() => setIsOpen(!isOpen)}>
                    {isOpen ? <X size={28} /> : <Menu size={28} />}
                </div>
            </div>
        </nav>
    );
};

export default Navbar;