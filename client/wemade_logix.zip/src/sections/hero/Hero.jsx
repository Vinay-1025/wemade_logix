import React from 'react';
import { motion } from 'framer-motion';
import {
  Atom,
  Code,
  Database,
  Terminal,
  Cpu,
  GitBranch,
  Cloud,
  Smartphone,
  Server,
  Network,
  Wifi,
  ShieldCheck,
  HardDrive,
  BrainCircuit
} from "lucide-react";

import './hero.css';
import { useNavigate } from 'react-router-dom';

const Hero = () => {
  const navigate = useNavigate();

  /* Core Software Stack */
  const innerOrbitIcons = [
    { Icon: Atom, color: "#61DAFB", delay: 0 },        // React
    { Icon: Code, color: "#F7DF1E", delay: 4 },        // JavaScript
    { Icon: Terminal, color: "#68A063", delay: 8 },    // Backend
    { Icon: Database, color: "#4DB33D", delay: 12 },   // Databases
    { Icon: GitBranch, color: "#F05032", delay: 16 },  // Git / Dev
    { Icon: Cpu, color: "#FF6F00", delay: 20 },        // AI / ML
  ];

  /* Advanced Platforms */
  const outerOrbitIcons = [
    { Icon: Cloud, color: "#FF9900", delay: 0 },        // Cloud
    { Icon: Server, color: "#6366F1", delay: 3 },       // Microservices
    { Icon: Network, color: "#2563EB", delay: 6 },      // APIs
    { Icon: ShieldCheck, color: "#22C55E", delay: 9 },  // Security
    { Icon: HardDrive, color: "#8B5CF6", delay: 12 },   // Data Platforms
    { Icon: Smartphone, color: "#3DDC84", delay: 15 },  // Mobile Apps
    { Icon: BrainCircuit, color: "#EC4899", delay: 18 }, // Generative AI
    { Icon: Wifi, color: "#0EA5E9", delay: 21 },        // Connectivity
  ];

  return (
    <section className="hero-section">
      <div className="container hero-container">

        {/* Left Content */}
        <motion.div
          className="hero-content"
          initial={{ opacity: 0, x: -50 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
        >
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2, duration: 0.8 }}
          >
            Accelerating Businesses with <br />
            <span>Intelligent Software & AI</span>
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4, duration: 0.8 }}
          >
            Accelyzei delivers enterprise-grade software platforms,
            AI-powered applications, and cloud-native solutions that
            enable organizations to innovate faster. From scalable
            microservices architectures to Generative AI systems,
            we help businesses unlock the full potential of modern
            digital technologies.
          </motion.p>

          <motion.div
            className="hero-actions"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6, duration: 0.8 }}
          >
            <button className="btn btn-primary" onClick={() => navigate("/services")}>Explore Solutions</button>
            <button className="btn btn-accent" onClick={() => navigate("/about")}>Know About Us</button>
          </motion.div>

        </motion.div>

        {/* Right Visual */}
        <div className="hero-visual">

          <div className="hero-orbit-container">

            {/* Center Logo */}
            <div className="hero-orbit-center">
              <img src="/fav_icon.png" alt="Accelyzei Logo" className="hero-logo-img" />
            </div>

            {/* Inner Orbit */}
            {innerOrbitIcons.map((item, index) => (
              <motion.div
                key={`inner-${index}`}
                className="hero-orbit-icon inner-ring"
                initial={{ opacity: 0 }}
                animate={{
                  opacity: 1,
                  rotate: 360
                }}
                transition={{
                  rotate: {
                    repeat: Infinity,
                    duration: 20,
                    ease: "linear",
                    delay: -item.delay
                  },
                  opacity: { duration: 1 }
                }}
                style={{
                  '--index': index,
                  '--count': innerOrbitIcons.length
                }}
              >
                <motion.div
                  className="hero-icon-wrapper"
                  style={{
                    boxShadow: `0 0 20px ${item.color}33`,
                    borderColor: item.color
                  }}
                  animate={{ rotate: -360 }}
                  transition={{
                    repeat: Infinity,
                    duration: 20,
                    ease: "linear",
                    delay: -item.delay
                  }}
                >
                  <item.Icon size={20} color={item.color} />
                </motion.div>
              </motion.div>
            ))}

            {/* Outer Orbit */}
            {outerOrbitIcons.map((item, index) => (
              <motion.div
                key={`outer-${index}`}
                className="hero-orbit-icon outer-ring"
                initial={{ opacity: 0 }}
                animate={{
                  opacity: 1,
                  rotate: -360
                }}
                transition={{
                  rotate: {
                    repeat: Infinity,
                    duration: 25,
                    ease: "linear",
                    delay: -item.delay
                  },
                  opacity: { duration: 1 }
                }}
                style={{
                  '--index': index,
                  '--count': outerOrbitIcons.length
                }}
              >
                <motion.div
                  className="hero-icon-wrapper"
                  style={{
                    boxShadow: `0 0 20px ${item.color}33`,
                    borderColor: item.color
                  }}
                  animate={{ rotate: 360 }}
                  transition={{
                    repeat: Infinity,
                    duration: 25,
                    ease: "linear",
                    delay: -item.delay
                  }}
                >
                  <item.Icon size={22} color={item.color} />
                </motion.div>
              </motion.div>
            ))}

            {/* Orbit Rings */}
            <div className="hero-orbit-ring hero-ring-1"></div>
            <div className="hero-orbit-ring hero-ring-2"></div>

          </div>

        </div>

      </div>
    </section>
  );
};

export default Hero;