import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import "./services-hero.css";

const sliderData = [
  {
    id: 1,
    title: "Generative AI Applications",
    description:
      "Designing intelligent applications powered by large language models, multimodal AI, and AI copilots tailored for enterprise use.",
    helpText:
      "Enables businesses to automate workflows, deploy AI assistants, and deliver intelligent digital experiences.",
    image:
      "https://images.unsplash.com/photo-1677442136019-21780ecad995?q=80&w=2070&auto=format&fit=crop",
  },
  {
    id: 2,
    title: "AI Product Engineering",
    description:
      "Building AI-first software products that integrate machine learning models, intelligent automation, and modern architectures.",
    helpText:
      "Transforms traditional software into intelligent systems capable of learning, predicting, and optimizing processes.",
    image:
      "https://images.unsplash.com/photo-1674027444485-cec3da58eef4?q=80&w=1332&auto=format&fit=crop",
  },
  {
    id: 3,
    title: "Enterprise Software Development",
    description:
      "Developing scalable enterprise platforms designed for performance, reliability, and modern digital experiences.",
    helpText:
      "Helps organizations modernize systems and build software platforms that scale with business growth.",
    image:
      "https://images.unsplash.com/photo-1460925895917-afdab827c52f?q=80&w=2015&auto=format&fit=crop",
  },
  {
    id: 4,
    title: "AI Data Platforms",
    description:
      "Designing intelligent data platforms that power analytics, AI models, and data-driven business intelligence.",
    helpText:
      "Unlocks the value of enterprise data through scalable data pipelines and intelligent analytics platforms.",
    image:
      "https://images.unsplash.com/photo-1551288049-bebda4e38f71?q=80&w=2070&auto=format&fit=crop",
  },
  {
    id: 5,
    title: "AI Workflow Automation",
    description:
      "Automating complex business operations using AI agents, intelligent pipelines, and advanced orchestration systems.",
    helpText:
      "Reduces manual effort and increases productivity through intelligent automation.",
    image:
      "https://images.unsplash.com/photo-1581092919535-7146ff1a590b?q=80&w=2070&auto=format&fit=crop",
  },
];

const ServicesHeroSlider = () => {
  const [activeIndex, setActiveIndex] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setActiveIndex((prev) => (prev + 1) % sliderData.length);
    }, 6000);

    return () => clearInterval(timer);
  }, []);

  const activeSlide = sliderData[activeIndex];

  return (
    <div className="services-hero-slider">
      <AnimatePresence initial={false}>
        <motion.div
          key={activeIndex}
          className="slider-background"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 1.2 }}
          style={{
            backgroundImage: `linear-gradient(rgba(10,15,30,0.75), rgba(10,15,30,0.9)), url(${activeSlide.image})`,
          }}
        />
      </AnimatePresence>

      <div className="container slider-content-container">

        {/* Left Side: Company Info */}

        <div className="brand-info">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >

            <h1 className="brand-name">
              Accely<span>zei</span>
            </h1>

            <p className="brand-tagline">
              Building the Future with AI-Driven Software
            </p>

            <p className="brand-description">
              Accelyzei specializes in building intelligent software systems
              powered by Artificial Intelligence and Generative AI. We create
              scalable enterprise platforms, AI copilots, and data-driven
              applications that help organizations innovate faster and operate
              smarter in a rapidly evolving digital landscape.
            </p>

          </motion.div>
        </div>

        {/* Right Side: Service Content */}

        <div className="service-content-area">

          <AnimatePresence mode="wait">

            <motion.div
              key={`content-${activeIndex}`}
              initial={{ opacity: 0, x: 40 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -40 }}
              transition={{ duration: 0.5 }}
              className="active-service-info"
            >

              <h2 className="service-title">
                {activeSlide.title}
              </h2>

              <p className="service-description">
                {activeSlide.description}
              </p>

              <div className="how-it-helps-box">
                <span className="help-label">
                  How It Helps
                </span>

                <p className="help-text">
                  {activeSlide.helpText}
                </p>
              </div>

            </motion.div>

          </AnimatePresence>

          {/* Navigation Thumbnails */}

          <div className="slider-nav-thumbnails">

            {Array.from({ length: sliderData.length - 1 }).map((_, i) => {

              const nextIndex = (activeIndex + 1 + i) % sliderData.length;
              const slide = sliderData[nextIndex];

              return (
                <motion.div
                  key={slide.id}
                  layout
                  className="nav-thumb"
                  onClick={() => setActiveIndex(nextIndex)}
                >

                  <div
                    className="thumb-img"
                    style={{ backgroundImage: `url(${slide.image})` }}
                  />

                </motion.div>
              );

            })}

          </div>

        </div>
      </div>
    </div>
  );
};

export default ServicesHeroSlider;