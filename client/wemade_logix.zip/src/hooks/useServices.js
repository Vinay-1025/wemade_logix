import { useQuery } from '@tanstack/react-query';
import axiosClient from '../api/axiosClient';

// Mock data for development
const mockServices = [
  { id: 1, title: 'Software Development', slug: 'software' },
  { id: 2, title: 'Gen AI Solutions', slug: 'gen-ai' },
  { id: 3, title: 'Cloud Solutions', slug: 'cloud' },
];

export const useServices = () => {
  return useQuery({
    queryKey: ['services'],
    queryFn: async () => {
      try {
        const res = await axiosClient.get('/services');
        return res.data.data;
      } catch (err) {
        console.warn('CMS API failed, returning mock data:', err);
        return mockServices;
      }
    },
  });
};
