import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ArrowRight, ExternalLink, Layers, Globe, Cpu, Zap } from 'lucide-react';
import { Link } from 'react-router-dom';
import SEO from '../../components/ui/SEO';
import './projects.css';

const categories = ['All', 'Web Apps', 'AI / ML', 'IoT', 'Enterprise', 'Cloud'];

const projectsData = [
    {
        id: 1,
        title: 'Smart Factory Dashboard',
        category: 'IoT',
        description: 'Real-time IoT monitoring platform for industrial automation with predictive maintenance capabilities.',
        images: [
            'https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?q=80&w=800&auto=format&fit=crop',
            'https://images.unsplash.com/photo-1563986768494-4dee2763ff3f?q=80&w=800&auto=format&fit=crop',
            'https://images.unsplash.com/photo-1518770660439-4636190af475?q=80&w=800&auto=format&fit=crop'
        ],
        tags: ['React', 'Node.js', 'MQTT', 'InfluxDB'],
    },
    {
        id: 2,
        title: 'AI-Powered Analytics Engine',
        category: 'AI / ML',
        description: 'Generative AI platform for business intelligence with natural language querying and automated insights.',
        images: [
            'https://images.unsplash.com/photo-1677442136019-21780ecad995?q=80&w=800&auto=format&fit=crop',
            'https://images.unsplash.com/photo-1551288049-bebda4e38f71?q=80&w=800&auto=format&fit=crop',
            'https://images.unsplash.com/photo-1620825937374-87fc1d6aafdd?q=80&w=800&auto=format&fit=crop'
        ],
        tags: ['Python', 'LLM', 'RAG', 'FastAPI'],
    },
    {
        id: 3,
        title: 'Enterprise Resource Hub',
        category: 'Enterprise',
        description: 'Scalable ERP system with AI-driven workflow automation and real-time collaboration tools.',
        images: [
            'https://images.unsplash.com/photo-1460925895917-afdab827c52f?q=80&w=800&auto=format&fit=crop',
            'https://images.unsplash.com/photo-1522071820081-009f0129c71c?q=80&w=800&auto=format&fit=crop',
            'https://images.unsplash.com/photo-1552664730-d307ca884978?q=80&w=800&auto=format&fit=crop'
        ],
        tags: ['React', 'Spring Boot', 'PostgreSQL'],
    },
    {
        id: 4,
        title: 'Cloud Migration Suite',
        category: 'Cloud',
        description: 'End-to-end cloud migration platform with zero-downtime deployment and automated infrastructure provisioning.',
        images: [
            'https://images.unsplash.com/photo-1451187580459-43490279c0fa?q=80&w=800&auto=format&fit=crop',
            'https://images.unsplash.com/photo-1667362080352-7e0454316d8a?q=80&w=800&auto=format&fit=crop',
            'https://images.unsplash.com/photo-1504384764586-bb4cdc1707b0?q=80&w=800&auto=format&fit=crop'
        ],
        tags: ['AWS', 'Terraform', 'Docker', 'K8s'],
    },
    {
        id: 5,
        title: 'HealthTech Patient Portal',
        category: 'Web Apps',
        description: 'HIPAA-compliant patient management platform with telemedicine integration and real-time vitals monitoring.',
        images: [
            'https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?q=80&w=800&auto=format&fit=crop',
            'https://images.unsplash.com/photo-1530497610245-94d3c16cda28?q=80&w=800&auto=format&fit=crop',
            'https://images.unsplash.com/photo-1516549655169-df83a0774514?q=80&w=800&auto=format&fit=crop'
        ],
        tags: ['Next.js', 'GraphQL', 'WebRTC'],
    },
    {
        id: 6,
        title: 'Smart City Infrastructure',
        category: 'IoT',
        description: 'Urban IoT ecosystem managing traffic, utilities, and environmental sensors across city networks.',
        images: [
            'https://images.unsplash.com/photo-1573804633927-bfcbcd909acd?q=80&w=800&auto=format&fit=crop',
            'https://images.unsplash.com/photo-1480714378408-67cf0d13bc1b?q=80&w=800&auto=format&fit=crop',
            'https://images.unsplash.com/photo-1473624898862-2374bb5203ce?q=80&w=800&auto=format&fit=crop'
        ],
        tags: ['Edge Computing', 'LoRaWAN', 'React'],
    },
];

const Projects = () => {
    const [activeFilter, setActiveFilter] = useState('All');

    const filteredProjects = activeFilter === 'All'
        ? projectsData
        : projectsData.filter(p => p.category === activeFilter);

    return (
        <div className="projects-page">
            <SEO
                title="Projects | We Made Logix"
                description="Explore our portfolio of cutting-edge projects spanning AI, IoT, Cloud, and Enterprise solutions."
            />

            {/* Hero */}
            <section className="projects-hero">
                <div className="container">
                    <motion.div
                        className="projects-hero-content"
                        initial={{ opacity: 0, y: 40 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.9 }}
                    >
                        <span className="section-tag">Our Portfolio</span>
                        <h1>Solutions That <span>Drive Impact</span></h1>
                        <p>
                            From intelligent automation to cloud-native platforms, explore how we engineer transformative digital experiences for global enterprises.
                        </p>

                        <div className="projects-stats-bar">
                            {[
                                { value: '50+', label: 'Projects Delivered' },
                                { value: '98%', label: 'Client Satisfaction' },
                                { value: '12+', label: 'Industries Served' },
                                { value: '3M+', label: 'Users Impacted' },
                            ].map((stat, i) => (
                                <motion.div
                                    key={i}
                                    className="projects-stat-item"
                                    initial={{ opacity: 0, y: 20 }}
                                    animate={{ opacity: 1, y: 0 }}
                                    transition={{ delay: 0.4 + i * 0.15 }}
                                >
                                    <div className="projects-stat-number">{stat.value}</div>
                                    <div className="projects-stat-label">{stat.label}</div>
                                </motion.div>
                            ))}
                        </div>
                    </motion.div>
                </div>
            </section>

            {/* Filter Tabs */}
            <section className="projects-filter-section">
                <div className="container">
                    <div className="projects-filter-tabs">
                        {categories.map((cat) => (
                            <button
                                key={cat}
                                className={`filter-tab ${activeFilter === cat ? 'active' : ''}`}
                                onClick={() => setActiveFilter(cat)}
                            >
                                {cat}
                            </button>
                        ))}
                    </div>
                </div>
            </section>

            {/* Project Showcase Rows */}
            <section className="projects-showcase-section">
                <div className="container">
                    <AnimatePresence mode="popLayout">
                        {filteredProjects.map((project, index) => (
                            <motion.div
                                key={project.id}
                                className={`project-showcase-row ${index % 2 !== 0 ? 'row-reversed' : ''}`}
                                layout
                                initial={{ opacity: 0, y: 100 }}
                                whileInView={{ opacity: 1, y: 0 }}
                                viewport={{ once: true, margin: "-100px" }}
                                transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
                            >
                                <div className="project-info-side">
                                    <div className="project-sticky-content">
                                        <motion.span 
                                            className="project-category-badge"
                                            initial={{ opacity: 0, x: -20 }}
                                            whileInView={{ opacity: 1, x: 0 }}
                                            viewport={{ once: true }}
                                            transition={{ delay: 0.2 }}
                                        >
                                            {project.category}
                                        </motion.span>
                                        
                                        <motion.h2
                                            initial={{ opacity: 0, y: 20 }}
                                            whileInView={{ opacity: 1, y: 0 }}
                                            viewport={{ once: true }}
                                            transition={{ delay: 0.3 }}
                                        >
                                            {project.title}
                                        </motion.h2>
                                        
                                        <motion.div 
                                            className="project-tags-list"
                                            initial={{ opacity: 0, y: 20 }}
                                            whileInView={{ opacity: 1, y: 0 }}
                                            viewport={{ once: true }}
                                            transition={{ delay: 0.4 }}
                                        >
                                            {project.tags.map((tag, idx) => (
                                                <span key={idx} className="tag-pill">{tag}</span>
                                            ))}
                                        </motion.div>
                                        
                                        <motion.p
                                            initial={{ opacity: 0, y: 20 }}
                                            whileInView={{ opacity: 1, y: 0 }}
                                            viewport={{ once: true }}
                                            transition={{ delay: 0.5 }}
                                        >
                                            {project.description}
                                        </motion.p>
                                        
                                        <motion.div 
                                            className="project-action-links"
                                            initial={{ opacity: 0, y: 20 }}
                                            whileInView={{ opacity: 1, y: 0 }}
                                            viewport={{ once: true }}
                                            transition={{ delay: 0.6 }}
                                        >
                                            <Link to="#" className="btn btn-primary">
                                                View Case Study <ArrowRight size={18} style={{ marginLeft: 8 }} />
                                            </Link>
                                            <Link to="#" className="link-secondary">
                                                Live Preview <ExternalLink size={18} style={{ marginLeft: 6 }} />
                                            </Link>
                                        </motion.div>
                                    </div>
                                </div>
                                
                                <div className="project-images-side">
                                    <div className="bento-image-grid">
                                        {project.images.map((img, i) => (
                                            <motion.div 
                                                key={i} 
                                                className={`bento-item bento-item-${i + 1}`}
                                                initial={{ opacity: 0, scale: 0.9, y: 30 }}
                                                whileInView={{ opacity: 1, scale: 1, y: 0 }}
                                                viewport={{ once: true }}
                                                transition={{ delay: 0.3 + (i * 0.2), duration: 0.7 }}
                                            >
                                                <img src={img} alt={`${project.title} screen ${i + 1}`} loading="lazy" />
                                                <div className="bento-overlay">
                                                    <div className="bento-info">
                                                        <span className="bento-info-icon"><ArrowRight size={20} /></span>
                                                        <span className="bento-info-text">
                                                            {i === 0 ? 'Main Dashboard' : i === 1 ? 'Analytics View' : 'Settings Panel'}
                                                        </span>
                                                    </div>
                                                </div>
                                            </motion.div>
                                        ))}
                                    </div>
                                </div>
                            </motion.div>
                        ))}
                    </AnimatePresence>
                </div>
            </section>

            {/* Featured Project */}
            <section className="featured-project-section">
                <div className="container">
                    <motion.div
                        className="featured-project-card"
                        initial={{ opacity: 0, y: 50 }}
                        whileInView={{ opacity: 1, y: 0 }}
                        viewport={{ once: true }}
                        transition={{ duration: 0.8 }}
                    >
                        <div className="featured-project-image">
                            <img
                                src="https://images.unsplash.com/photo-1551288049-bebda4e38f71?q=80&w=1000&auto=format&fit=crop"
                                alt="Featured Project"
                            />
                        </div>
                        <div className="featured-project-info">
                            <span className="featured-badge">⭐ Featured Project</span>
                            <h2>Enterprise <span>AI Analytics</span> Platform</h2>
                            <p>
                                A comprehensive business intelligence platform powered by Generative AI,
                                enabling natural language data querying, automated report generation,
                                and predictive analytics for Fortune 500 enterprises.
                            </p>
                            <div className="featured-metrics">
                                <div className="featured-metric">
                                    <div className="metric-value">40%</div>
                                    <div className="metric-label">Faster Decisions</div>
                                </div>
                                <div className="featured-metric">
                                    <div className="metric-value">10x</div>
                                    <div className="metric-label">Data Processing</div>
                                </div>
                                <div className="featured-metric">
                                    <div className="metric-value">99.9%</div>
                                    <div className="metric-label">Uptime SLA</div>
                                </div>
                            </div>
                            <Link to="/contact" className="btn btn-primary">
                                Start Your Project <ArrowRight size={18} style={{ marginLeft: 8 }} />
                            </Link>
                        </div>
                    </motion.div>
                </div>
            </section>

            {/* CTA */}
            <section className="projects-cta-section">
                <div className="container">
                    <motion.div
                        className="projects-cta-content"
                        initial={{ opacity: 0, y: 30 }}
                        whileInView={{ opacity: 1, y: 0 }}
                        viewport={{ once: true }}
                    >
                        <h2>Have an <span>Idea?</span> Let's Build It.</h2>
                        <p>
                            Transform your vision into a powerful digital product.
                            Our experts are ready to engineer your next breakthrough.
                        </p>
                        <Link to="/contact" className="btn btn-primary">
                            Get In Touch <ArrowRight size={18} style={{ marginLeft: 8 }} />
                        </Link>
                    </motion.div>
                </div>
            </section>
        </div>
    );
};

export default Projects;
