import React from 'react';
import { motion } from 'framer-motion';
import { ArrowRight, Clock, Users, BookOpen, Award, Monitor, Zap, Target, TrendingUp } from 'lucide-react';
import { Link } from 'react-router-dom';
import SEO from '../../components/ui/SEO';
import './trainings.css';

const coursesData = [
    {
        id: 1,
        title: 'Full-Stack Web Development',
        category: 'Development',
        level: 'beginner',
        duration: '12 Weeks',
        students: '2.4k+',
        modules: 48,
        description: 'Master HTML, CSS, JavaScript, React, Node.js and build production-ready web applications from scratch.',
        image: 'https://images.unsplash.com/photo-1498050108023-c5249f4df085?q=80&w=800&auto=format&fit=crop',
    },
    {
        id: 2,
        title: 'AI & Machine Learning Bootcamp',
        category: 'Artificial Intelligence',
        level: 'intermediate',
        duration: '16 Weeks',
        students: '1.8k+',
        modules: 64,
        description: 'Deep dive into neural networks, NLP, computer vision, and deploy production ML models with Python & TensorFlow.',
        image: 'https://images.unsplash.com/photo-1677442136019-21780ecad995?q=80&w=800&auto=format&fit=crop',
    },
    {
        id: 3,
        title: 'Cloud Architecture & DevOps',
        category: 'Cloud Computing',
        level: 'advanced',
        duration: '10 Weeks',
        students: '1.2k+',
        modules: 36,
        description: 'AWS, Azure, Kubernetes, CI/CD pipelines, Infrastructure as Code, and microservices architecture.',
        image: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?q=80&w=800&auto=format&fit=crop',
    },
    {
        id: 4,
        title: 'IoT & Embedded Systems',
        category: 'IoT Engineering',
        level: 'intermediate',
        duration: '14 Weeks',
        students: '900+',
        modules: 52,
        description: 'Design smart devices with Arduino, Raspberry Pi, sensor networks, edge computing, and MQTT protocols.',
        image: 'https://images.unsplash.com/photo-1518770660439-4636190af475?q=80&w=800&auto=format&fit=crop',
    },
    {
        id: 5,
        title: 'Generative AI & LLM Engineering',
        category: 'Gen AI',
        level: 'advanced',
        duration: '8 Weeks',
        students: '3.1k+',
        modules: 28,
        description: 'Build RAG pipelines, fine-tune LLMs, prompt engineering, and create AI-powered applications with LangChain.',
        image: 'https://images.unsplash.com/photo-1655720828018-edd2daec9349?q=80&w=800&auto=format&fit=crop',
    },
    {
        id: 6,
        title: 'Cybersecurity Fundamentals',
        category: 'Security',
        level: 'beginner',
        duration: '10 Weeks',
        students: '1.5k+',
        modules: 40,
        description: 'Learn ethical hacking, penetration testing, network security, and security operations center practices.',
        image: 'https://images.unsplash.com/photo-1550751827-4bd374c3f58b?q=80&w=800&auto=format&fit=crop',
    },
];

const whyData = [
    {
        icon: Monitor,
        title: 'Live & Interactive',
        desc: 'Real-time sessions with industry experts. Ask questions, get instant feedback.',
    },
    {
        icon: Award,
        title: 'Certified Programs',
        desc: 'Earn industry-recognized certificates that boost your career credibility.',
    },
    {
        icon: Target,
        title: 'Project-Based Learning',
        desc: 'Build real-world projects that go directly into your portfolio.',
    },
    {
        icon: TrendingUp,
        title: 'Career Support',
        desc: 'Resume reviews, mock interviews, and job placement assistance included.',
    },
];

const pathSteps = [
    { num: '01', title: 'Foundations', desc: 'Core concepts, tools & environment setup' },
    { num: '02', title: 'Deep Dive', desc: 'Advanced techniques & hands-on projects' },
    { num: '03', title: 'Capstone', desc: 'Real-world project with mentor guidance' },
    { num: '04', title: 'Career Launch', desc: 'Portfolio, certification & placement' },
];

const Trainings = () => {
    return (
        <div className="trainings-page">
            <SEO
                title="Trainings | We Made Logix"
                description="Upskill with our industry-leading training programs in AI, Cloud, IoT, Full-Stack Development, and more."
            />

            {/* Hero */}
            <section className="trainings-hero">
                <div className="container">
                    <motion.div
                        className="trainings-hero-content"
                        initial={{ opacity: 0, y: 40 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.9 }}
                    >
                        <span className="section-tag">Training Programs</span>
                        <h1>Upskill with <span>Industry Experts</span></h1>
                        <p>
                            Hands-on, project-based training programs designed to fast-track your career in technology.
                            Learn from engineers who build real products.
                        </p>
                    </motion.div>
                </div>
            </section>

            {/* Programs Grid */}
            <section className="trainings-programs-section">
                <div className="container">
                    <div className="trainings-section-header">
                        <h2>Explore Our <span>Programs</span></h2>
                        <p>
                            Industry-relevant curricula designed with real-world application in mind.
                            Each program includes hands-on projects and career support.
                        </p>
                    </div>

                    <div className="courses-grid">
                        {coursesData.map((course, i) => (
                            <motion.div
                                key={course.id}
                                className="course-card"
                                initial={{ opacity: 0, y: 30 }}
                                whileInView={{ opacity: 1, y: 0 }}
                                transition={{ delay: i * 0.1 }}
                                viewport={{ once: true }}
                            >
                                <div className="course-card-header">
                                    <img src={course.image} alt={course.title} loading="lazy" />
                                    <span className={`course-level-badge ${course.level}`}>
                                        {course.level}
                                    </span>
                                    <span className="course-duration-badge">
                                        <Clock size={12} /> {course.duration}
                                    </span>
                                </div>
                                <div className="course-card-body">
                                    <span className="course-card-category">{course.category}</span>
                                    <h3>{course.title}</h3>
                                    <p>{course.description}</p>
                                    <div className="course-meta">
                                        <span className="course-meta-item">
                                            <Users size={16} /> {course.students} Students
                                        </span>
                                        <span className="course-meta-item">
                                            <BookOpen size={16} /> {course.modules} Modules
                                        </span>
                                    </div>
                                    <button className="course-enroll-btn">
                                        Enroll Now <ArrowRight size={16} />
                                    </button>
                                </div>
                            </motion.div>
                        ))}
                    </div>
                </div>
            </section>

            {/* Why Choose Us */}
            <section className="trainings-why-section">
                <div className="container">
                    <div className="trainings-section-header">
                        <h2>Why Choose <span>Our Training?</span></h2>
                        <p>
                            We don't just teach — we prepare you for real engineering roles with industry-grade tools and mentorship.
                        </p>
                    </div>

                    <div className="why-grid">
                        {whyData.map((item, i) => (
                            <motion.div
                                key={i}
                                className="why-card"
                                initial={{ opacity: 0, y: 30 }}
                                whileInView={{ opacity: 1, y: 0 }}
                                transition={{ delay: i * 0.12 }}
                                viewport={{ once: true }}
                            >
                                <div className="why-icon-wrapper">
                                    <item.icon size={28} />
                                </div>
                                <h3>{item.title}</h3>
                                <p>{item.desc}</p>
                            </motion.div>
                        ))}
                    </div>
                </div>
            </section>

            {/* Learning Path */}
            <section className="learning-path-section">
                <div className="container">
                    <div className="learning-path-header">
                        <h2>Your <span>Learning Path</span></h2>
                        <p>
                            A structured, step-by-step journey from fundamentals to career-ready expertise.
                        </p>
                    </div>

                    <div className="learning-path-steps">
                        {pathSteps.map((step, i) => (
                            <motion.div
                                key={i}
                                className="path-step"
                                initial={{ opacity: 0, y: 30 }}
                                whileInView={{ opacity: 1, y: 0 }}
                                transition={{ delay: i * 0.15 }}
                                viewport={{ once: true }}
                            >
                                <div className="path-step-number">{step.num}</div>
                                <h4>{step.title}</h4>
                                <p>{step.desc}</p>
                            </motion.div>
                        ))}
                    </div>
                </div>
            </section>

            {/* CTA */}
            <section className="trainings-cta">
                <div className="container">
                    <motion.div
                        initial={{ opacity: 0, y: 30 }}
                        whileInView={{ opacity: 1, y: 0 }}
                        viewport={{ once: true }}
                    >
                        <h2>Ready to <span>Level Up?</span></h2>
                        <p>
                            Join thousands of learners who have transformed their careers with our expert-led programs.
                        </p>
                        <Link to="/contact" className="btn btn-primary">
                            Get Started Today <ArrowRight size={18} style={{ marginLeft: 8 }} />
                        </Link>
                    </motion.div>
                </div>
            </section>
        </div>
    );
};

export default Trainings;
