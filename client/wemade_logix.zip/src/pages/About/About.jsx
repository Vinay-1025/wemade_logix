import React from "react";
import { motion } from "framer-motion";
import { Target, Shield, Lightbulb, Rocket, Cpu, Globe } from "lucide-react";
import SEO from "../../components/ui/SEO";
import "./about.css";

const heroImg =
  "https://images.unsplash.com/photo-1581092160562-40aa08e78837?q=80&w=2070&auto=format&fit=crop";

const missionImg =
  "https://images.unsplash.com/photo-1451187580459-43490279c0fa?q=80&w=2072&auto=format&fit=crop";

const teamImg =
  "https://images.unsplash.com/photo-1522071820081-009f0129c71c?q=80&w=2070&auto=format&fit=crop";

const About = () => {
  const values = [
    {
      title: "AI Innovation",
      desc: "Building intelligent systems powered by Generative AI and modern data platforms.",
      icon: Cpu,
    },
    {
      title: "Engineering Excellence",
      desc: "Delivering scalable enterprise-grade software with precision and reliability.",
      icon: Shield,
    },
    {
      title: "Global Collaboration",
      desc: "Partnering with organizations worldwide to build impactful digital solutions.",
      icon: Globe,
    },
    {
      title: "Future Driven",
      desc: "Exploring cutting-edge AI, automation, and cloud-native architectures.",
      icon: Rocket,
    },
  ];

  const milestones = [
    {
      year: "2022",
      title: "Company Founded",
      desc: "Accelyzei was established with a mission to build intelligent software and AI solutions.",
    },
    {
      year: "2023",
      title: "Enterprise Platforms",
      desc: "Delivered scalable enterprise software systems for global clients.",
    },
    {
      year: "2024",
      title: "Generative AI Expansion",
      desc: "Built advanced LLM-based platforms and AI automation tools.",
    },
    {
      year: "2025",
      title: "Global Technology Partner",
      desc: "Supporting organizations worldwide with AI and cloud-native solutions.",
    },
  ];

  return (
    <div className="about-page">
      <SEO
        title="About"
        description="Learn about Accelyzei — a technology company building enterprise software, AI platforms, and generative AI solutions."
      />

      {/* HERO */}
      <section
        className="about-hero-section"
        style={{ backgroundImage: `url(${heroImg})` }}
      >
        <div className="about-hero-overlay"></div>

        <div className="container">
          <motion.div
            className="about-hero-content"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <span className="about-tag">About Accelyzei</span>

            <h1>
              Building the Future with <span>AI & Software</span>
            </h1>

            <p>
              Accelyzei is a technology company focused on building enterprise
              software platforms, Generative AI applications, and cloud-native
              solutions that help organizations innovate faster.
            </p>
          </motion.div>
        </div>
      </section>

      {/* MISSION */}
      <section className="mission-vision-section">
        <div className="container mission-grid">
          <motion.div
            className="mission-text"
            initial={{ opacity: 0, x: -40 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
          >
            <span className="section-tag">Our Mission</span>

            <h2>
              Accelerating Innovation with <span>Intelligent Software</span>
            </h2>

            <p>
              Our mission is to empower organizations with intelligent software
              systems, data-driven platforms, and Generative AI technologies
              that unlock new possibilities in digital transformation.
            </p>

            <p className="mission-quote">
              “We believe the future belongs to organizations that combine
              software engineering excellence with AI-driven intelligence.”
            </p>
          </motion.div>

          <motion.div
            className="mission-image-container"
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
          >
            <img src={missionImg} alt="Accelyzei Vision" />
          </motion.div>
        </div>
      </section>

      {/* VALUES */}
      <section className="values-section">
        <div className="container">
          <div className="section-header">
            <h2>
              Our <span>Core Values</span>
            </h2>
          </div>

          <div className="values-grid">
            {values.map((v, i) => (
              <motion.div
                key={i}
                className="value-card"
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
                viewport={{ once: true }}
              >
                <div className="value-icon-wrapper">
                  <v.icon size={28} />
                </div>

                <h3>{v.title}</h3>
                <p>{v.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* TIMELINE */}
      <section className="milestones-section">
        <div className="container">
          <div className="section-header">
            <h2>
              Our <span>Journey</span>
            </h2>
          </div>

          <div className="timeline">
            {milestones.map((m, i) => (
              <motion.div
                key={i}
                className="timeline-item"
                initial={{ opacity: 0, y: 40 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
              >
                <div className="timeline-dot"></div>

                <div className="milestone-year">{m.year}</div>

                <h4>{m.title}</h4>
                <p>{m.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* TEAM */}
      <section
        className="team-section"
        style={{
          backgroundImage: `linear-gradient(rgba(10,15,30,0.9), rgba(10,15,30,0.9)), url(${teamImg})`,
        }}
      >
        <div className="container">
          <div className="section-header-team">
            <h2>
              Leadership <span>Team</span>
            </h2>

            <p>Experts in AI, cloud engineering, and enterprise software.</p>
          </div>

          <div className="team-grid">
            <LeadershipCard
              name="Founder"
              role="CEO & Founder"
              bio="Leading Accelyzei’s vision for AI-driven software platforms."
            />

            <LeadershipCard
              name="Chief Architect"
              role="Head of Engineering"
              bio="Architect of scalable enterprise and AI systems."
            />

            <LeadershipCard
              name="Technology Lead"
              role="AI & Data Platforms"
              bio="Driving innovation in Generative AI and intelligent automation."
            />
          </div>
        </div>
      </section>
    </div>
  );
};

const LeadershipCard = ({ name, role, bio }) => (
  <motion.div
    className="team-card"
    whileHover={{ y: -10 }}
    initial={{ opacity: 0, scale: 0.95 }}
    whileInView={{ opacity: 1, scale: 1 }}
    viewport={{ once: true }}
  >
    <div className="member-info">
      <div className="member-role">{role}</div>
      <h3>{name}</h3>
      <p>{bio}</p>
    </div>
  </motion.div>
);

export default About;