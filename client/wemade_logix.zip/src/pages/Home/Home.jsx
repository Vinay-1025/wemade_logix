import Hero from '../../sections/hero/Hero';
import AboutPreview from '../../sections/hero/AboutPreview';
import ServiceGrid from '../../sections/services/ServiceGrid';
import Technologies from '../../sections/technologies/Technologies';
import CaseStudies from '../../sections/testimonials/CaseStudies';
import Testimonials from '../../sections/testimonials/Testimonials';
import BlogPreview from '../../sections/blog-preview/BlogPreview';
import CTASection from '../../sections/hero/CTASection';
import SEO from '../../components/ui/SEO';
import './home.css';

const Home = () => {
  return (
    <div className="home-page-main">
      <SEO
        title="Home"
        description="Accelyzei Technologies provides cutting-edge Gen AI, Cloud and Software Solutions for the modern enterprise."
      />
      <Hero />
      <AboutPreview />
      <ServiceGrid />
      <Technologies />
      <CaseStudies />
      <Testimonials />
      <BlogPreview />
      <CTASection />
    </div>
  );
};

export default Home;
